package np.com.naxa.iset;

public final class Permissions {
    public final static int RC_GPS_PERM = 201;
    public final static int RC_PHONE = 51;
}
