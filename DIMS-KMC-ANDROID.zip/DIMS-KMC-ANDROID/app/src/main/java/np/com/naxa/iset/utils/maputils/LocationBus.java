package np.com.naxa.iset.utils.maputils;

import android.location.Location;

public interface LocationBus {

    public void locationTransporter(Location location);
}
