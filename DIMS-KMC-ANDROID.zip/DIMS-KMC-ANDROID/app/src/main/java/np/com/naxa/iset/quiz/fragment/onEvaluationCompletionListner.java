package np.com.naxa.iset.quiz.fragment;

/**
 * Created by user on 12/20/2017.
 */

public interface onEvaluationCompletionListner {

    void displayResult(String result);
}
