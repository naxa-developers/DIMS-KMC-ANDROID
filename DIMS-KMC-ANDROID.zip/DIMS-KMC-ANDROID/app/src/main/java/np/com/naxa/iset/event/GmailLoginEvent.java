package np.com.naxa.iset.event;

public class GmailLoginEvent {

    public static class loginButtonClick{


        public loginButtonClick() {
        }
    }
}
