package np.com.naxa.iset.quiz.fragment;

/**
 * Created by nishon.tan on 4/21/2017.
 */

public interface onFormFinishedListener {
    void evaluateForm();

    void lastFragment();

    void firstFragment();




}
