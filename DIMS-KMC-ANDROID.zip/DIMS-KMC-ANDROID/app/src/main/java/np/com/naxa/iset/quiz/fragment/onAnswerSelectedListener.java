package np.com.naxa.iset.quiz.fragment;

public interface onAnswerSelectedListener {
    void onAnswerSelected(String question, String answer);

    void formFragment();

}
