package np.com.naxa.iset.mapboxmap.mapboxutils;

public interface MapDataLayerDialogCloseListen {

    public void onDialogClose();

    public void isFirstTime();
}
