package np.com.naxa.iset.utils.recycleviewutils;

/**
 * Created by samir on 01/12/18..
 */

public enum  RecyclerViewType {
    LINEAR_VERTICAL,LINEAR_HORIZONTAL,GRID;
}
