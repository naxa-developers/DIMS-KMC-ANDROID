package np.com.naxa.iset.home;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {

}
